(function () {
    'use strict';

    let tagField = createTagsField();
    document.body.append(tagField.element);

    function createTagsField(){
        let fieldElement=document.createElement('div');
        fieldElement.classList.add('tagField');
        fieldElement.id='div';

        let setTag = new Set();
        let textTagLength=0;
        let textTag='';

        let tagFieldnew={
            element: fieldElement,
            getTags: function() {
                let arr=[];
                for (let value of setTag){
                    arr.push(value);
                }
                return arr;
            },
            destroy: function() {
                fieldElement.remove();
            //    ------ удаление событий не успел переделать ------------
            }
        };

        tagFieldnew.element.addEventListener('keyup',()=>{
            if (tagFieldnew.element.innerText.slice(-1)===','||tagFieldnew.element.innerText.slice(-2)==='\n'){
                textTag=tagFieldnew.element.innerText.slice(textTagLength,-1);
                createTag(textTag);
            }
        });

        function createTag(value) {
            if (value!==null) {
                setTag.add(value);
            }
            tagFieldnew.element.innerText = '';

            for ( let i of setTag){
                let tagSpan = document.createElement('div');
                tagSpan.classList.add('Tags');
                tagSpan.innerText = i;
                tagSpan.id = i;
                div.append(tagSpan);

                tagSpan.addEventListener('click',()=>{
                    setTag.delete(tagSpan.id);
                    tagSpan.remove();
                    placeCaret();
                });
            }
            textTagLength=tagFieldnew.element.innerText.length+1;

            div.insertAdjacentHTML("beforeend", '&nbsp');
            placeCaret();

            function placeCaret() {
                    let range = document.createRange();
                    range.setStartAfter(tagFieldnew.element.lastChild);
                    range.collapse(true);
                    let selection = window.getSelection();
                    selection.removeAllRanges();
                    selection.addRange(range);
            }

            textTag='';
        }

        return tagFieldnew;

    }


})();
